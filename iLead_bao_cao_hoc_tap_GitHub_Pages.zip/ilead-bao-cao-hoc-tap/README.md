# Báo cáo học tập iLead Transformation Program

Trang web tĩnh (một file `index.html`), số liệu chốt ngày 26/11/2026.

## Deploy lên GitHub Pages

1. Tạo repository mới trên GitHub (khuyến nghị: **Private**, xem lưu ý bên dưới).
2. Upload toàn bộ file trong thư mục này lên nhánh `main`:
   `index.html`, `.nojekyll`, `robots.txt`, `README.md`.
   (Trên giao diện web: **Add file → Upload files**, kéo thả cả 4 file, rồi **Commit changes**.
   Nếu không thấy `.nojekyll` vì là file ẩn, có thể bỏ qua: trang vẫn chạy.)
3. Vào **Settings → Pages**. Ở **Build and deployment**, chọn **Source: Deploy from a branch**,
   **Branch: `main`**, thư mục **`/ (root)`**, rồi **Save**.
4. Sau 1–2 phút, đường dẫn trang hiện ở đầu mục **Pages**
   (dạng `https://<tên-tài-khoản>.github.io/<tên-repo>/`).

## Cập nhật số liệu

Thay file `index.html` bằng bản mới (giữ nguyên tên file) và commit. GitHub Pages tự deploy lại.

## Lưu ý bảo mật

- Trang chứa họ tên, mã nhân viên, đơn vị và kết quả học của CBNV.
  **GitHub Pages trên tài khoản thường là công khai** (kể cả khi repo để Private, trang Pages
  vẫn ai có link cũng xem được). Chỉ GitHub Enterprise Cloud mới giới hạn được người xem trang Pages.
- Username đăng nhập **không lưu dạng chữ** trong file: chỉ lưu mã băm SHA-256 kèm salt.
  Ô tra cứu băm giá trị người dùng nhập rồi so khớp, nên vẫn tra được bằng username.
- `robots.txt` và thẻ `noindex` yêu cầu công cụ tìm kiếm không lập chỉ mục trang,
  nhưng **không** ngăn người có link truy cập.
